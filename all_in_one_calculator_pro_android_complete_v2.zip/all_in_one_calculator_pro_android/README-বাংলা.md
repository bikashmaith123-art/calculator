# All-in-One Calculator Pro — Android App Starter

এই ZIP-এ আপনার সর্বশেষ স্বচ্ছ ম্যাপ-ওভারলে HTML ফাইলটি Android অ্যাপের ভিতরে চালানোর জন্য Capacitor project হিসেবে রাখা হয়েছে। অ্যাপ ইনস্টল হলে আলাদা অ্যাপ আইকন থেকে খুলবে; Chrome-এর address bar/tab দেখাবে না।

## Android APK তৈরি (কম্পিউটার ছাড়াই GitHub Actions দিয়ে)

1. ZIP Extract করে ফোল্ডারের সব ফাইল GitHub repository-তে আপলোড করুন।
2. Repository-র নাম/branch `main` রাখুন।
3. GitHub-এ Actions tab খুলুন।
4. `Build Android APK` workflow বেছে নিয়ে `Run workflow` চাপুন।
5. Build শেষ হলে workflow-এর Artifacts থেকে `all-in-one-calculator-pro-debug-apk` ডাউনলোড করুন।
6. ZIP Extract করে `app-debug.apk` Android-এ ইনস্টল করুন। প্রয়োজনে Android Settings থেকে ওই উৎসের APK install অনুমতি দিন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- এটি প্রথম Android app shell / packaging starter; এখনো signed release APK নয়।
- অ্যাপের ভিতরে Android WebView ব্যবহার হয়, কিন্তু Chrome browser UI থাকে না।
- GPS permission, native file picker, robust project database, automatic recovery/autosave এবং project export/import আলাদা করে পরীক্ষা ও সংযুক্ত করতে হবে। এই starter ZIP-এ এগুলো সম্পূর্ণ হয়েছে বলে দাবি করা হচ্ছে না।
- Satellite imagery আনতে ইন্টারনেট লাগবে।
- Release APK তৈরি ও নিরাপদে আপডেট দেওয়ার জন্য পরের ধাপে release signing key configure করতে হবে। সেটির password কাউকে পাঠাবেন না।

## প্রযুক্তি

Capacitor 8 + Android. Android build GitHub Actions-এ হয়; তাই শুধু Android ফোন/ট্যাবলেট দিয়েও repository-তে ফাইল আপলোড ও workflow চালানো সম্ভব।


## এই সংস্করণে যুক্ত/রাখা ফিচার
- স্যাটেলাইট/হাইব্রিড/রোড ম্যাপের ওপর স্বচ্ছ ড্রয়িং বোর্ড।
- পেন, শেষ দাগ Undo, সব দাগ মুছুন এবং নতুন ইরেজার (কাছের সম্পূর্ণ স্ট্রোক মুছবে)।
- দুই কোঅর্ডিনেট থেকে দুই ব্যাসার্ধের বৃত্তের ছেদবিন্দু হিসাব; বাঁ/ডান/দুটো ছেদবিন্দুই নতুন পয়েন্ট হিসেবে যোগ করা যায়।
- পয়েন্ট তালিকার ✎ বোতামে পয়েন্টের নাম পরিবর্তন।
- একাধিক আলাদা প্রজেক্ট তৈরি, সেভ, নাম বদল, খোলা, মোছা, JSON ব্যাকআপ Export ও Import।
- বর্তমান প্রজেক্টের ডেটা পরিবর্তনের সময় অটো-সেভ। তবুও নিয়মিত JSON ব্যাকআপ ডাউনলোড করে রাখুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই ZIP হলো Android Studio/GitHub Actions দিয়ে APK বানানোর সোর্স প্যাকেজ; APK নিজে এই ZIP-এর মধ্যে নেই।
- এখানে Android APK বিল্ড চালিয়ে ইনস্টল-পরীক্ষা করা হয়নি।
- লাইভ GPS-এর জন্য Android অ্যাপে Location permission/Capacitor Geolocation প্লাগইনের runtime permission flow পরীক্ষা করতে হবে।
- ম্যাপ টাইল দেখাতে ইন্টারনেট দরকার।
